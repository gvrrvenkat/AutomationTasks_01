package stepDefinitions;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObject.Homepage;
import pageObject.Inventorypage;
import pageObject.Loginpage;
import pageObject.Manufacturingpage;
import java.lang.Thread;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Demo {
    WebDriver webDriver;	
    @BeforeClass
    public void setUp(){
        WebDriverManager.chromedriver().setup();
        webDriver = new ChromeDriver();
        webDriver.manage().timeouts().implicitlyWait(30000,TimeUnit.SECONDS);
        WebDriverWait waitDriver = new WebDriverWait(webDriver, 30000);
        webDriver.manage().window().maximize();
        webDriver.get("https://aspireapp.odoo.com");
    }

    @Test
    public void demo(){
        Loginpage loginpage= new Loginpage(webDriver);
        Homepage homepage= new Homepage(webDriver);
        Inventorypage inventorypage= new Inventorypage(webDriver);
        Manufacturingpage manufacturingpage = new Manufacturingpage(webDriver);
        
        loginpage.login();
        homepage.navigateToInventory();
        inventorypage.navigateToProducts();
        String strProductName="Auto_Test_002"; 
        inventorypage.createProduct(strProductName);
        homepage.navigateToHomemenu();        
        homepage.navigateToManufacturing();
        manufacturingpage.createManufactureOrder(strProductName);
        String DoneStatus = manufacturingpage.DoneStatus();
        Assert.assertEquals(DoneStatus, "true");
        String ManfProduct = manufacturingpage.ProductName();
        Assert.assertEquals(ManfProduct,strProductName);
    }
   /*@AfterClass
    public void tearDown()
    {
    	webDriver.close();
    	webDriver.quit();
    }*/

}
