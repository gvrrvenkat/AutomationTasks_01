package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Loginpage {
    WebDriver webDriver;
    public Loginpage(WebDriver driver){
        this.webDriver = driver;
    }

    By email=By.name("login");
    By password=By.name("password");
    By Login=By.xpath("//button[@type=\"submit\"]");
    By Profile=By.xpath("//span[@class=\"oe_topbar_name\"]");

    public void login(){
        webDriver.findElement(email).sendKeys("user@aspireapp.com");
        webDriver.findElement(password).sendKeys("@sp1r3app");
        webDriver.findElement(Login).click();
        Assert.assertTrue(webDriver.findElement(Profile).isDisplayed(),"User Logged in");
    }

}
