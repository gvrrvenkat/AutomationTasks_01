package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Manufacturingpage {
    WebDriver webDriver;
    public String strManufactureRef;
    public Manufacturingpage(WebDriver driver){
        this.webDriver = driver;
    }
    By CreateManufacture=By.xpath("//button[contains(text(),'Create')]");
    By manProduct = By.cssSelector("div[name='product_id'] input[id *=\"field_input\"]");
    By Save=By.xpath("//button[contains(text(),'Save')]");
    By DialogCreate = By.xpath("//div[@class='modal-dialog']//button//span[contains(text(),'Create')]");
    By ManufactureReferenceValue = By.cssSelector("span[placeholder='Manufacturing Reference']");
    By Confirm=By.xpath("//button//span[contains(text(),'Confirm')]");
    By MarkAsDone = By.xpath("(//button//span[contains(text(),'Mark as Done')])[2]");
    By ConfirmationOk = By.xpath("//div[@class='modal-dialog']//button//span[contains(text(),'Ok')]");
    By ImmediateProductionConfirmation = By.xpath("//footer//button//span[contains(text(),'Apply')]");
    By ProductID = By.xpath("//a[@name='product_id']");
    By Done = By.xpath("//div[@name=\"state\"]//button[contains(text(),'Done')]");
    
    WebDriverWait wait = new WebDriverWait(webDriver,30);
    
    public void createManufactureOrder(String ManfactureProduct) {
    	webDriver.findElement(CreateManufacture).click();
    	webDriver.findElement(manProduct).sendKeys(ManfactureProduct);
    	webDriver.findElement(manProduct).sendKeys(Keys.ARROW_DOWN);
    	webDriver.findElement(manProduct).sendKeys(Keys.ENTER);
    	webDriver.findElement(Save).click();
    	webDriver.findElement(DialogCreate).click();
    	
    	wait.until(ExpectedConditions.elementToBeClickable(Confirm));
    	webDriver.findElement(Confirm).click();
    	wait.until(ExpectedConditions.elementToBeClickable(ManufactureReferenceValue));
    	strManufactureRef = webDriver.findElement(ManufactureReferenceValue).getAttribute("outerText");
    	System.out.println(strManufactureRef);
    	wait.until(ExpectedConditions.elementToBeClickable(MarkAsDone));
    	webDriver.findElement(MarkAsDone).click();
    	webDriver.findElement(ConfirmationOk).click();
    	webDriver.findElement(ImmediateProductionConfirmation).click();
    }
    public String ProductName()
    {
    	wait.until(ExpectedConditions.elementToBeClickable(ProductID));
    	return webDriver.findElement(ProductID).getAttribute("innerText");
    }
    public String DoneStatus()
    {
    	wait.until(ExpectedConditions.elementToBeClickable(Done));
    	return webDriver.findElement(Done).getAttribute("aria-checked");
    }
    
}
