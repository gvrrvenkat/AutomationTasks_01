package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Homepage {
    WebDriver webDriver;
    public Homepage(WebDriver driver){
        this.webDriver = driver;
    }
    By inventory=By.xpath("//div[text()='Inventory']//parent::a");
    By home=By.cssSelector("a[title='Home menu']");
    By manufacturing = By.xpath("//div[text()='Manufacturing']//parent::a");
    public void navigateToInventory() {
        webDriver.findElement(inventory).click();
    }
    public void navigateToHomemenu() {
    	
    	webDriver.findElement(home).click();
    }
    public void navigateToManufacturing() {
    	webDriver.findElement(manufacturing).click();
    }
}
