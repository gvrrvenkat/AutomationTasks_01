package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Inventorypage {
    WebDriver webDriver;
    public Inventorypage(WebDriver driver){
        this.webDriver = driver;
    }
    By ProductsTab=By.xpath("//span[text()='Products']//parent::button");
    By ProductsmenuLink=By.xpath("//a[text()='Products']");
    By Create=By.xpath("//button[contains(text(),'Create')]");
    By name=By.cssSelector("input[name='name']");
    By Save=By.xpath("//button[contains(text(),'Save')]");
    By Edit=By.xpath("//button[contains(text(),'Edit')]");
    By UpdateQuantity=By.name("action_update_quantity_on_hand");
    public void navigateToProducts() {
        webDriver.findElement(ProductsTab).click();
        webDriver.findElement(ProductsmenuLink).click();
    }

    public void createProduct(String productName){
        webDriver.findElement(Create).click();
        webDriver.findElement(name).sendKeys(productName);
        webDriver.findElement(Save).click();
        webDriver.findElement(Edit).click();
        webDriver.findElement(UpdateQuantity).click();
    }
}
